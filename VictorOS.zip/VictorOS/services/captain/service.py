from VictorOS.contracts.execution_result import ExecutionResult


class CaptainService:

    def task_completed(self, result: ExecutionResult):

        print()

        print(f"Brain > {result.summary}")

        print()